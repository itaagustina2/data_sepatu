<?php

include 'coneksi.php';

$mereksepatu= $_POST['mereksepatu'];
$ukuransepatu= $_POST['ukuransepatu'];
$stoksepatu= $_POST['stoksepatu'];
$harga= $_POST['harga'];




 mysqli_query($dbconnect, "INSERT INTO data_sepatu VALUES ( NULL, '$mereksepatu','$ukuransepatu','$stoksepatu','$harga')");

 header("location:databarang.php")
 ?>