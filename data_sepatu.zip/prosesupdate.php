<?php

 include 'coneksi.php';
  $id = $_POST['id'];
  $mereksepatu= $_POST['merek_sepatu'];
  $ukuransepatu= $_POST['ukuran_sepatu'];
  $stoksepatu= $_POST['stok_sepatu'];
  $harga= $_POST['harga'];



  mysqli_query($dbconnect, "UPDATE `data_sepatu` SET `merek_sepatu`='$mereksepatu' , `ukuran_sepatu`='$ukuransepatu' , `stok_sepatu`='$stoksepatu' , `harga`='$harga' WHERE `id`='$id' ");
  header("location:databarang.php");
  ?>