<?php

$host = "localhost";
$user = "root";
$pass = "";
$db	  = "data_sepatu";

$dbconnect = new mysqli("$host","$user","$pass","$db");

?>